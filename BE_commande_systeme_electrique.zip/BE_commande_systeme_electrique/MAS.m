% BE systeme commande electrique


clear all
close all
clc 


J=0.025;
f=0.01;
E=540;

p=2;
Msr= 0.182;
Lr= 0.194;
Ls= 0.182;
Rr =1.15;
Rs= 1.6;
w = 2*3.14*50;



